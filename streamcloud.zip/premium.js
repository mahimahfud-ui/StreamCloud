/* StreamCloud premium behaviour layer. Loaded after the inline scripts in index.html. */
(function () {
  "use strict";
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var slug = function (n) { return String(n).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, ""); };
  var esc = function (s) { return String(s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var store = {
    get: function (k, d) { try { var v = localStorage.getItem(k); return v == null ? d : v; } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem(k, v); return true; } catch (e) { return false; } },
    del: function (k) { try { localStorage.removeItem(k); } catch (e) {} }
  };
  var toast = function (m) { if (window.scToast) window.scToast(m); };
  var cat = function () { return window.MAHIFLIX_CATALOG || { sites: [], apps: [] }; };
  var q = $("#q"), adF = $("#adFilter"), sortS = $("#sortSelect"), tools = $(".catalog-selects"), chips = $(".filter-chips");
  if (!q || !tools || !chips || !adF || !sortS) return;
  var favOnly = false;

  function mk(tag, cls, html) { var e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; }

  /* Toolbar: favourites chip, grid/list toggle, reset */
  var favChip = mk("button", "sc-chip", "Favourites"); favChip.type = "button"; favChip.setAttribute("aria-pressed", "false");
  chips.appendChild(favChip);
  var seg = mk("div", "sc-seg"); seg.setAttribute("role", "group"); seg.setAttribute("aria-label", "Layout");
  var gridBtn = mk("button", "", "Grid"), listBtn = mk("button", "", "List"); gridBtn.type = listBtn.type = "button";
  seg.appendChild(gridBtn); seg.appendChild(listBtn); tools.appendChild(seg);
  var resetBtn = mk("button", "sc-reset", "Reset filters"); resetBtn.type = "button"; resetBtn.hidden = true; tools.appendChild(resetBtn);

  function setView(v) {
    document.documentElement.classList.toggle("list-view", v === "list");
    gridBtn.setAttribute("aria-pressed", String(v !== "list")); listBtn.setAttribute("aria-pressed", String(v === "list"));
    store.set("streamcloud-view", v);
  }
  gridBtn.addEventListener("click", function () { setView("grid"); });
  listBtn.addEventListener("click", function () { setView("list"); });
  setView(store.get("streamcloud-view", "grid") === "list" ? "list" : "grid");

  function isFiltered() {
    var chip = $(".filter-chip.active");
    return !!q.value.trim() || adF.value !== "all" || sortS.value !== "score" || (chip && chip.dataset.filter !== "all");
  }

  /* Re-applied after every render of the catalogue */
  function apply() {
    var view = $(".view.active"); if (!view) return;
    var shown = 0;
    $$(".card", view).forEach(function (c) {
      var hide = favOnly && store.get("mahiflix-favorite:" + slug(c.dataset.name || ""), "") !== "1";
      c.classList.toggle("sc-hide", hide);
      if (!hide && c.style.display !== "none") shown++;
      var f = $(".fav", c);
      if (f) {
        var on = f.dataset.on === "1";
        f.setAttribute("aria-pressed", String(on));
        f.setAttribute("aria-label", (on ? "Remove " : "Add ") + c.dataset.name + (on ? " from" : " to") + " Favourites");
      }
    });
    var empty = $("#empty");
    if (favOnly && !shown && empty) { empty.textContent = "No favourites here yet. Press + on a card to save it."; empty.style.display = "block"; }
    else if (empty && !favOnly) { empty.style.display = ""; }
    favChip.classList.toggle("on", favOnly); favChip.setAttribute("aria-pressed", String(favOnly));
    resetBtn.hidden = !(favOnly || isFiltered());
  }
  favChip.addEventListener("click", function () { favOnly = !favOnly; if (!favOnly) { var e = $("#empty"); if (e) e.style.display = "none"; } apply(); });
  resetBtn.addEventListener("click", function () {
    favOnly = false;
    q.value = ""; q.dispatchEvent(new Event("input", { bubbles: true }));
    adF.value = "all"; adF.dispatchEvent(new Event("change", { bubbles: true }));
    sortS.value = "score"; sortS.dispatchEvent(new Event("change", { bubbles: true }));
    var all = $('.filter-chip[data-filter="all"]'); if (all) all.click();
    apply(); toast("Filters reset");
  });
  var mo = new MutationObserver(apply);
  ["sitesView", "appsView"].forEach(function (id) { var v = document.getElementById(id); if (v) mo.observe(v, { childList: true, subtree: true }); });
  ["input", "change", "click"].forEach(function (ev) { document.addEventListener(ev, function () { setTimeout(apply, 0); }); });

  apply();
})();