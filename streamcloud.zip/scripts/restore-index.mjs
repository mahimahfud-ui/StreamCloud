import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT = path.resolve(__dirname, "..");

const ghIndexPath = path.join(ROOT, "gh-index.html");
let html = fs.readFileSync(ghIndexPath, "utf-8");

// 1. Ensure intro counter bug fix: #intro is strictly display:none unless html.intro-on
html = html.replace(
  `.intro{display:none}`,
  `#intro{display:none!important}html.intro-on #intro{display:grid!important}`
);

// 2. In intro end() function, ensure intro is hidden with display:none and aria-hidden="true"
html = html.replace(
  `setTimeout(function(){d.classList.remove("intro-on","intro-leave")},650)`,
  `setTimeout(function(){d.classList.remove("intro-on","intro-leave");var it=document.getElementById("intro");if(it){it.hidden=true;it.style.display="none";it.setAttribute("aria-hidden","true");}},650)`
);

// 3. Add Admin link in nav
html = html.replace(
  `<li id="recsNav" hidden><a href="#recs">Movies &amp; Series</a></li>`,
  `<li id="recsNav" hidden><a href="#recs">Movies &amp; Series</a></li>\n    <li><a href="./admin.html" target="_blank" rel="noopener">Admin</a></li>`
);

// 4. In footer links, add Admin link
html = html.replace(
  `<div class="links"><a href="https://www.instagram.com/mahimahfud/" target="_blank" rel="noopener noreferrer">Contact Mahi</a><a href="#privacy" data-legal-toggle>Privacy</a><a href="#disclaimer" data-legal-toggle>Disclaimer</a></div>`,
  `<div class="links"><a href="https://www.instagram.com/mahimahfud/" target="_blank" rel="noopener noreferrer">Contact Mahi</a><a href="./admin.html" target="_blank" rel="noopener">Admin</a><a href="#privacy" data-legal-toggle>Privacy</a><a href="#disclaimer" data-legal-toggle>Disclaimer</a></div>`
);

// 5. In detail modal openDetail: safe visit link
html = html.replace(
  `const visit=document.getElementById("detailVisit");visit.href=item.url;
    visit.target="_blank";visit.rel="noopener noreferrer";
    visit.textContent=currentList!=="sites"?"Open App Page":"Visit Site";`,
  `const visit=document.getElementById("detailVisit");
    if(item.url && /^https?:\\/\\//i.test(item.url)){
      visit.href=item.url;
      visit.removeAttribute("aria-disabled");
      visit.target="_blank";visit.rel="noopener noreferrer nofollow";
      visit.textContent=currentList!=="sites"?"Open App Page":"Visit Site";
    } else {
      visit.removeAttribute("href");
      visit.setAttribute("aria-disabled","true");
      visit.textContent="Link unavailable";
    }`
);

// 6. Add live /api/items loader before </script> in catalog script
const syncScript = `
  // Sync custom items created in Admin
  fetch("/api/items")
    .then(function(r){return r.json()})
    .then(function(items){
      if(!Array.isArray(items)) return;
      var added = false;
      items.forEach(function(it){
        if(it.type === "website" && typeof S !== "undefined"){
          if(!S.some(function(x){return x.name.toLowerCase() === it.name.toLowerCase()})){
            S.unshift({
              name: it.name,
              url: it.url,
              domain: it.url ? new URL(it.url).hostname : "Website",
              ads: it.adLevel === "none" ? 0 : it.adLevel === "some" ? 1 : 2,
              pop: (it.rating || 8) * 10,
              smooth: 85,
              langs: 85,
              new: it.isNew,
              desc: it.desc || "",
              logoSources: it.poster ? [it.poster] : []
            });
            added = true;
          }
        } else if(it.type === "movieapp" && typeof A !== "undefined"){
          if(!A.some(function(x){return x.name.toLowerCase() === it.name.toLowerCase()})){
            A.unshift({
              appType: "movie",
              name: it.name,
              url: it.url,
              downloadUrl: it.apk || it.url,
              domain: it.url ? new URL(it.url).hostname : "App",
              ads: it.adLevel === "none" ? 0 : it.adLevel === "some" ? 1 : 2,
              pop: (it.rating || 8) * 10,
              smooth: 85,
              langs: 85,
              new: it.isNew,
              desc: it.desc || "",
              logoSources: it.poster ? [it.poster] : []
            });
            added = true;
          }
        } else if(it.type === "musicapp" && typeof M !== "undefined"){
          if(!M.some(function(x){return x.name.toLowerCase() === it.name.toLowerCase()})){
            M.unshift({
              appType: "music",
              kind: "app",
              name: it.name,
              url: it.url,
              downloadUrl: it.apk || it.url,
              domain: it.url ? new URL(it.url).hostname : "Music",
              ads: it.adLevel === "none" ? 0 : it.adLevel === "some" ? 1 : 2,
              pop: (it.rating || 8) * 10,
              smooth: 85,
              langs: 85,
              new: it.isNew,
              desc: it.desc || "",
              logoSources: it.poster ? [it.poster] : []
            });
            added = true;
          }
        }
      });
      if(added && typeof render === "function") render();
    })
    .catch(function(){});
`;

html = html.replace(`render();
  fetch("./link-status.json"`, `${syncScript}\n  render();\n  fetch("./link-status.json"`);

const outPath = path.join(ROOT, "index.html");
fs.writeFileSync(outPath, html, "utf-8");
console.log(`Restored index.html from gh-index.html (${html.length} bytes)`);
