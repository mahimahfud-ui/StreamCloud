import fs from "fs";
import path from "path";
import crypto from "crypto";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT = path.resolve(__dirname, "..");

const recsPath = path.join(ROOT, "data", "recommendations.json");
let recs = { movies: [], series: [] };
try {
  recs = JSON.parse(fs.readFileSync(recsPath, "utf-8"));
} catch (e) {}

const ghIndexPath = path.join(ROOT, "gh-index.html");
const html = fs.readFileSync(ghIndexPath, "utf-8");

// Extract S, A, M arrays from html
function extractArray(name) {
  const match = html.match(new RegExp(`const ${name}=\\[([\\s\\S]*?)\\];`));
  if (!match) return [];
  try {
    const raw = `[${match[1]}]`;
    return eval(raw);
  } catch (e) {
    return [];
  }
}

const S = extractArray("S");
const A = extractArray("A");
const M = extractArray("M");

const items = [];
const now = Date.now();

// Websites
for (const s of S) {
  items.push({
    id: "site-" + crypto.randomUUID().slice(0, 8),
    type: "website",
    name: s.name,
    url: s.url || "",
    apk: "",
    poster: (s.logoSources && s.logoSources[0]) || "",
    year: null,
    runtime: null,
    rating: (s.pop ? Math.round(s.pop / 10 * 10) / 10 : 8.0),
    industry: "Global",
    genres: ["Streaming", "Web"],
    adLevel: s.ads === 0 ? "none" : s.ads === 1 ? "some" : "more",
    desc: s.desc || "",
    status: "published",
    isNew: Boolean(s.new),
    createdAt: now,
    updatedAt: now
  });
}

// Movie Apps
for (const a of A) {
  items.push({
    id: "mapp-" + crypto.randomUUID().slice(0, 8),
    type: "movieapp",
    name: a.name,
    url: a.url || "",
    apk: a.downloadUrl || "",
    poster: (a.logoSources && a.logoSources[0]) || "",
    year: null,
    runtime: null,
    rating: (a.pop ? Math.round(a.pop / 10 * 10) / 10 : 8.2),
    industry: "Global",
    genres: ["Android", "Streaming", "APK"],
    adLevel: a.ads === 0 ? "none" : a.ads === 1 ? "some" : "more",
    desc: a.desc || "",
    status: "published",
    isNew: Boolean(a.new),
    createdAt: now,
    updatedAt: now
  });
}

// Music Apps
for (const m of M) {
  items.push({
    id: "mus-" + crypto.randomUUID().slice(0, 8),
    type: "musicapp",
    name: m.name,
    url: m.url || "",
    apk: m.downloadUrl || "",
    poster: (m.logoSources && m.logoSources[0]) || "",
    year: null,
    runtime: null,
    rating: (m.pop ? Math.round(m.pop / 10 * 10) / 10 : 8.0),
    industry: "Global",
    genres: ["Music", "Audio", "APK"],
    adLevel: m.ads === 0 ? "none" : m.ads === 1 ? "some" : "more",
    desc: m.desc || "",
    status: "published",
    isNew: Boolean(m.new),
    createdAt: now,
    updatedAt: now
  });
}

// Movies
for (const mov of recs.movies || []) {
  items.push({
    id: "mov-" + crypto.randomUUID().slice(0, 8),
    type: "movie",
    name: mov.title,
    url: mov.imdbId ? `https://www.imdb.com/title/${mov.imdbId}/` : "",
    apk: "",
    poster: mov.poster || "",
    year: mov.year || 2024,
    runtime: mov.runtime || 120,
    rating: mov.rating?.value || 8.0,
    industry: mov.industry || "Hollywood",
    genres: Array.isArray(mov.genres) ? mov.genres : [mov.genres || "Drama"],
    adLevel: "none",
    desc: mov.overview || mov.note || "",
    status: "published",
    isNew: false,
    createdAt: now,
    updatedAt: now
  });
}

// Web Series
for (const ser of recs.series || []) {
  items.push({
    id: "ser-" + crypto.randomUUID().slice(0, 8),
    type: "series",
    name: ser.title,
    url: ser.imdbId ? `https://www.imdb.com/title/${ser.imdbId}/` : "",
    apk: "",
    poster: ser.poster || "",
    year: ser.year || 2024,
    runtime: ser.runtime || 50,
    rating: ser.rating?.value || 8.2,
    industry: ser.industry || "Hollywood",
    genres: Array.isArray(ser.genres) ? ser.genres : [ser.genres || "Drama"],
    adLevel: "none",
    desc: ser.overview || ser.note || "",
    status: "published",
    isNew: false,
    createdAt: now,
    updatedAt: now
  });
}

const outPath = path.join(ROOT, "data.json");
fs.writeFileSync(outPath, JSON.stringify(items, null, 2));
console.log(`Seeded ${items.length} items to data.json`);
