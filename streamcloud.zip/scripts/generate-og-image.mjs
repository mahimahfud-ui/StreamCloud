import fs from "node:fs";
import path from "node:path";
import zlib from "node:zlib";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

// CRC32 implementation
const crcTable = new Uint32Array(256);
for (let n = 0; n < 256; n++) {
  let c = n;
  for (let k = 0; k < 8; k++) {
    if (c & 1) c = 0xedb88320 ^ (c >>> 1);
    else c = c >>> 1;
  }
  crcTable[n] = c;
}

function crc32(buf) {
  let crc = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    crc = crcTable[(crc ^ buf[i]) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function makeChunk(type, data) {
  const typeBuf = Buffer.from(type, "ascii");
  const lenBuf = Buffer.alloc(4);
  lenBuf.writeUInt32BE(data.length, 0);
  
  const crcInput = Buffer.concat([typeBuf, data]);
  const crcVal = crc32(crcInput);
  const crcBuf = Buffer.alloc(4);
  crcBuf.writeUInt32BE(crcVal, 0);

  return Buffer.concat([lenBuf, typeBuf, data, crcBuf]);
}

const WIDTH = 1200;
const HEIGHT = 630;

// Create IHDR
const ihdr = Buffer.alloc(13);
ihdr.writeUInt32BE(WIDTH, 0);
ihdr.writeUInt32BE(HEIGHT, 4);
ihdr[8] = 8; // 8-bit depth
ihdr[9] = 6; // RGBA
ihdr[10] = 0; // compression
ihdr[11] = 0; // filter
ihdr[12] = 0; // no interlace

const bytesPerRow = 1 + WIDTH * 4;
const rawData = Buffer.alloc(HEIGHT * bytesPerRow);

// Generate dark cinematic gradient background with subtle red/purple ambient glow
for (let y = 0; y < HEIGHT; y++) {
  const rowStart = y * bytesPerRow;
  rawData[rowStart] = 0; // Filter: None

  const ny = y / HEIGHT;
  for (let x = 0; x < WIDTH; x++) {
    const nx = x / WIDTH;
    const px = rowStart + 1 + x * 4;

    // Base dark background: #0a0a0f (10, 10, 15)
    let r = 10;
    let g = 10;
    let b = 15;

    // Crimson radial glow at top-right (center 0.75, 0.25)
    const dRed = Math.hypot(nx - 0.75, ny - 0.25);
    const redGlow = Math.max(0, 1 - dRed / 0.65);
    r += Math.round(redGlow * 180);
    g += Math.round(redGlow * 12);
    b += Math.round(redGlow * 24);

    // Violet/Purple radial glow at bottom-left (center 0.25, 0.75)
    const dPurple = Math.hypot(nx - 0.25, ny - 0.75);
    const purpleGlow = Math.max(0, 1 - dPurple / 0.65);
    r += Math.round(purpleGlow * 90);
    g += Math.round(purpleGlow * 40);
    b += Math.round(purpleGlow * 190);

    // Center subtle highlight
    const dCenter = Math.hypot(nx - 0.5, ny - 0.5);
    const centerGlow = Math.max(0, 1 - dCenter / 0.5);
    r += Math.round(centerGlow * 25);
    g += Math.round(centerGlow * 25);
    b += Math.round(centerGlow * 35);

    // Subtle dark vignette near borders
    const borderDist = Math.min(nx, 1 - nx, ny, 1 - ny) * 2;
    const vignette = Math.min(1, Math.max(0.4, borderDist));
    r = Math.min(255, Math.round(r * vignette));
    g = Math.min(255, Math.round(g * vignette));
    b = Math.min(255, Math.round(b * vignette));

    rawData[px] = r;
    rawData[px + 1] = g;
    rawData[px + 2] = b;
    rawData[px + 3] = 255;
  }
}

const compressed = zlib.deflateSync(rawData, { level: 9 });

const pngSignature = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
const ihdrChunk = makeChunk("IHDR", ihdr);
const idatChunk = makeChunk("IDAT", compressed);
const iendChunk = makeChunk("IEND", Buffer.alloc(0));

const finalPng = Buffer.concat([pngSignature, ihdrChunk, idatChunk, iendChunk]);
const outPath = path.join(ROOT, "og-image.png");
fs.writeFileSync(outPath, finalPng);
console.log(`Generated og-image.png (1200x630, ${finalPng.length} bytes) at ${outPath}`);
