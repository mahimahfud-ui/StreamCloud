import fs from "fs";
import path from "path";

const ghHtml = fs.readFileSync("gh-index.html", "utf-8");

// 1. Add extra CSS for iOS spring motion, floating add listing button, admin modal, bottom sheet, and IMDb preview card
const customStyles = `
<!-- iOS Spring Transitions & Floating Add Listing Modal Styles -->
<style>
:root {
  --ios-spring: cubic-bezier(0.25, 1, 0.5, 1);
  --ios-ease: cubic-bezier(0.32, 0.72, 0, 1);
}

.view {
  transition: opacity 0.35s var(--ios-spring), transform 0.35s var(--ios-spring);
}
.view.ios-fade-in {
  animation: iosViewIn 0.38s var(--ios-spring) both;
}
@keyframes iosViewIn {
  0% { opacity: 0; transform: translate3d(0, 12px, 0) scale(0.992); }
  100% { opacity: 1; transform: translate3d(0, 0, 0) scale(1); }
}

/* Sleek Circular Glass Floating Add Listing Button */
.floating-add-btn {
  position: fixed;
  right: 24px;
  bottom: 24px;
  z-index: 9990;
  width: 56px;
  height: 56px;
  border-radius: 50%;
  background: rgba(24, 24, 28, 0.85);
  backdrop-filter: blur(20px) saturate(180%);
  -webkit-backdrop-filter: blur(20px) saturate(180%);
  border: 1.5px solid rgba(229, 9, 20, 0.55);
  color: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  box-shadow: 0 10px 28px rgba(0, 0, 0, 0.65), 0 0 20px rgba(229, 9, 20, 0.35);
  transition: all 0.4s var(--ios-spring);
}
.floating-add-btn:hover {
  transform: scale(1.1) translateY(-3px);
  border-color: #ff3344;
  background: rgba(229, 9, 20, 0.3);
  box-shadow: 0 16px 36px rgba(0, 0, 0, 0.75), 0 0 28px rgba(229, 9, 20, 0.6);
}
.floating-add-btn:active {
  transform: scale(0.92);
}
.floating-add-btn svg {
  transition: transform 0.4s var(--ios-spring);
}
.floating-add-btn:hover svg {
  transform: rotate(90deg);
}

/* Admin Add Listing Modal & iOS Bottom Sheet */
.admin-modal {
  position: fixed;
  inset: 0;
  z-index: 9999;
  display: none;
  align-items: center;
  justify-content: center;
  padding: 16px;
}
.admin-modal.open {
  display: flex;
}
.admin-scrim {
  position: absolute;
  inset: 0;
  background: rgba(8, 9, 12, 0.84);
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
}
.admin-panel {
  position: relative;
  width: min(560px, 94vw);
  max-height: min(90vh, 860px);
  overflow-y: auto;
  background: linear-gradient(165deg, rgba(28, 29, 36, 0.96), rgba(16, 17, 22, 0.98));
  border: 1px solid rgba(255, 255, 255, 0.14);
  border-radius: 20px;
  padding: 26px;
  box-shadow: 0 28px 80px rgba(0, 0, 0, 0.8), 0 0 40px rgba(229, 9, 20, 0.15);
  animation: adminModalIn 0.38s var(--ios-spring) both;
}
@keyframes adminModalIn {
  from { opacity: 0; transform: translateY(20px) scale(0.96); }
  to { opacity: 1; transform: translateY(0) scale(1); }
}

.ios-drag-handle {
  display: none;
  width: 44px;
  height: 5px;
  background: rgba(255, 255, 255, 0.28);
  border-radius: 99px;
  margin: 0 auto 16px;
}

@media (max-width: 640px) {
  .admin-modal {
    align-items: flex-end;
    padding: 0;
  }
  .admin-panel {
    width: 100%;
    max-height: 88vh;
    border-radius: 24px 24px 0 0;
    padding: 18px 20px 34px;
    animation: iosSheetUp 0.42s var(--ios-spring) both;
  }
  .ios-drag-handle {
    display: block;
  }
}
@keyframes iosSheetUp {
  from { transform: translateY(100%); }
  to { transform: translateY(0); }
}

.admin-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 20px;
}
.admin-header h3 {
  margin: 0;
  font-size: 20px;
  font-weight: 800;
  color: #fff;
  display: flex;
  align-items: center;
  gap: 10px;
}
.admin-header h3 span.badge {
  position: static;
  background: var(--red);
  font-size: 10px;
  padding: 2px 7px;
  border-radius: 4px;
}
.admin-close {
  background: rgba(255, 255, 255, 0.08);
  border: 1px solid rgba(255, 255, 255, 0.15);
  color: #fff;
  width: 32px;
  height: 32px;
  border-radius: 50%;
  font-size: 18px;
  display: grid;
  place-items: center;
  cursor: pointer;
  transition: all 0.2s ease;
}
.admin-close:hover {
  background: rgba(255, 255, 255, 0.18);
  transform: scale(1.05);
}

.admin-step {
  display: none;
}
.admin-step.active {
  display: block;
}

.cat-picker {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(130px, 1fr));
  gap: 10px;
  margin: 18px 0;
}
.cat-btn {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 8px;
  padding: 16px 10px;
  border-radius: 12px;
  background: rgba(255, 255, 255, 0.05);
  border: 1.5px solid rgba(255, 255, 255, 0.12);
  color: #eee;
  cursor: pointer;
  transition: all 0.25s var(--ios-spring);
  font-size: 13px;
  font-weight: 700;
  text-align: center;
}
.cat-btn .icon {
  font-size: 24px;
}
.cat-btn:hover, .cat-btn.selected {
  background: rgba(229, 9, 20, 0.15);
  border-color: var(--red);
  color: #fff;
  transform: translateY(-2px);
}

.pin-box {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 16px;
  padding: 24px 10px;
  text-align: center;
}
.pin-input {
  font-size: 28px;
  letter-spacing: 12px;
  text-align: center;
  width: 200px;
  padding: 12px 14px;
  background: rgba(0, 0, 0, 0.5);
  border: 1.5px solid rgba(255, 255, 255, 0.22);
  border-radius: 12px;
  color: #fff;
  font-family: monospace;
}
.pin-input:focus {
  border-color: var(--red);
  outline: none;
}
.admin-err {
  color: #ff6b6b;
  font-size: 13px;
  min-height: 18px;
  text-align: center;
}

.form-group {
  margin-bottom: 15px;
}
.form-group label {
  display: block;
  font-size: 12px;
  font-weight: 700;
  color: #aaa;
  margin-bottom: 6px;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
.form-group input, .form-group select, .form-group textarea {
  width: 100%;
  padding: 11px 14px;
  background: rgba(0, 0, 0, 0.45);
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-radius: 10px;
  color: #fff;
  font-size: 14px;
  font-family: inherit;
  box-sizing: border-box;
  transition: border-color 0.2s;
}
.form-group input:focus, .form-group select:focus, .form-group textarea:focus {
  outline: none;
  border-color: var(--red);
}

.search-enrich-row {
  display: flex;
  gap: 8px;
}
.search-enrich-row input {
  flex: 1;
}
.btn-enrich {
  background: #f5c518;
  color: #000;
  border: none;
  border-radius: 10px;
  padding: 0 16px;
  font-size: 13px;
  font-weight: 800;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  white-space: nowrap;
  transition: all 0.2s ease;
}
.btn-enrich:hover {
  background: #ffe18a;
  transform: translateY(-1px);
}
.btn-enrich:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

/* IMDb Real-time Preview Card */
.imdb-preview-card {
  display: flex;
  gap: 14px;
  background: rgba(255, 255, 255, 0.04);
  border: 1px solid rgba(245, 197, 24, 0.35);
  border-radius: 14px;
  padding: 12px;
  margin: 14px 0;
  align-items: flex-start;
}
.imdb-preview-card img {
  width: 82px;
  height: 120px;
  object-fit: cover;
  border-radius: 8px;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.6);
  flex-shrink: 0;
  background: #111;
}
.imdb-preview-meta {
  flex: 1;
  min-width: 0;
}
.imdb-preview-title {
  font-size: 16px;
  font-weight: 800;
  color: #fff;
  margin: 0 0 4px;
}
.imdb-rating-badge {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  background: #f5c518;
  color: #000;
  font-weight: 800;
  font-size: 12px;
  padding: 2px 7px;
  border-radius: 5px;
  margin-bottom: 6px;
}
.imdb-preview-desc {
  font-size: 12px;
  line-height: 1.4;
  color: #bbb;
  margin: 0;
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.submit-btn {
  width: 100%;
  padding: 13px;
  border: none;
  border-radius: 10px;
  background: var(--red);
  color: #fff;
  font-size: 15px;
  font-weight: 800;
  cursor: pointer;
  transition: all 0.25s var(--ios-spring);
  box-shadow: 0 4px 18px rgba(229, 9, 20, 0.4);
}
.submit-btn:hover {
  background: #f40612;
  transform: translateY(-2px);
  box-shadow: 0 6px 22px rgba(229, 9, 20, 0.6);
}
.submit-btn:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

/* Toast Notification (iOS Floating Banner) */
.ios-toast {
  position: fixed;
  top: 24px;
  left: 50%;
  transform: translateX(-50%) translateY(-30px);
  z-index: 10005;
  background: rgba(24, 25, 30, 0.95);
  border: 1px solid rgba(255, 255, 255, 0.18);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  color: #fff;
  font-size: 14px;
  font-weight: 600;
  padding: 12px 24px;
  border-radius: 99px;
  box-shadow: 0 14px 40px rgba(0, 0, 0, 0.6);
  opacity: 0;
  pointer-events: none;
  transition: all 0.4s var(--ios-spring);
}
.ios-toast.show {
  opacity: 1;
  transform: translateX(-50%) translateY(0);
}
</style>
`;

// Insert customStyles right before </head>
let resultHtml = ghHtml.replace("</head>", customStyles + "\n</head>");

// 2. Insert Floating Button, iOS Toast, and Admin Modal right before </body>
const adminMarkup = `
<!-- iOS Floating Notification Banner -->
<div class="ios-toast" id="adminToast" role="status" aria-live="polite"></div>

<!-- Sleek Circular Glass Floating Add Listing Action Button -->
<button class="floating-add-btn" id="portalAddBtn" type="button" aria-label="Add Listing" title="Add Listing">
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round">
    <path d="M12 5v14M5 12h14"></path>
  </svg>
</button>

<!-- Private Multi-Category Add Listing Modal with IMDb Auto-Enrichment -->
<div class="admin-modal" id="adminModal" aria-hidden="true">
  <div class="admin-scrim" id="adminScrim"></div>
  <div class="admin-panel" role="dialog" aria-modal="true" aria-labelledby="adminTitle">
    <div class="ios-drag-handle"></div>
    <div class="admin-header">
      <h3 id="adminTitle">Add To StreamCloud <span class="badge">SECURE</span></h3>
      <button class="admin-close" id="adminCloseBtn" type="button" aria-label="Close modal">&times;</button>
    </div>

    <!-- Step 1: Security PIN -->
    <div class="admin-step active" id="stepPin">
      <div class="pin-box">
        <label for="adminPinInput" style="color:#ddd;font-size:14px;font-weight:600;">Enter Access PIN</label>
        <input type="password" id="adminPinInput" class="pin-input" maxlength="4" placeholder="••••" autocomplete="off" inputmode="numeric">
        <p class="admin-err" id="pinErr"></p>
        <button class="submit-btn" id="verifyPinBtn" type="button">Verify Access</button>
      </div>
    </div>

    <!-- Step 2: Choose Category -->
    <div class="admin-step" id="stepCategory">
      <p style="color:#aaa;font-size:13px;margin:0 0 12px;">Select what you want to add to StreamCloud:</p>
      <div class="cat-picker">
        <button class="cat-btn" type="button" data-cat="movie">
          <span class="icon">🎬</span>
          <span>Movie</span>
        </button>
        <button class="cat-btn" type="button" data-cat="series">
          <span class="icon">📺</span>
          <span>Web Series</span>
        </button>
        <button class="cat-btn" type="button" data-cat="sites">
          <span class="icon">🌐</span>
          <span>Website</span>
        </button>
        <button class="cat-btn" type="button" data-cat="apps">
          <span class="icon">📱</span>
          <span>Movie App</span>
        </button>
        <button class="cat-btn" type="button" data-cat="music">
          <span class="icon">🎵</span>
          <span>Music App</span>
        </button>
      </div>
      <p class="admin-err" id="catErr"></p>
      <button class="submit-btn" id="chooseCatBtn" type="button">Continue</button>
    </div>

    <!-- Step 3: Media Form (Movie / Series with Real-time IMDb Auto-Enrichment) -->
    <div class="admin-step" id="stepMedia">
      <form id="mediaForm">
        <div class="form-group">
          <label for="mediaSearchTitle">Title (Auto-Enrich from IMDb)</label>
          <div class="search-enrich-row">
            <input type="text" id="mediaSearchTitle" placeholder="e.g. Inception, Mimi, Stranger Things" required autocomplete="off">
            <button class="btn-enrich" id="enrichBtn" type="button">
              <span>⭐ Fetch IMDb</span>
            </button>
          </div>
        </div>

        <!-- Live Auto-Enriched IMDb Preview Card -->
        <div class="imdb-preview-card" id="imdbPreviewCard" style="display:none;">
          <img id="previewPoster" src="" alt="Poster preview">
          <div class="imdb-preview-meta">
            <div class="imdb-rating-badge" id="previewRating">⭐ -- / 10</div>
            <h4 class="imdb-preview-title" id="previewTitle">Title</h4>
            <p style="font-size:11px;color:#888;margin:0 0 6px;" id="previewSub">Year · Genres</p>
            <p class="imdb-preview-desc" id="previewPlot">Synopsis...</p>
          </div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
          <div class="form-group">
            <label for="mediaYear">Release Year</label>
            <input type="number" id="mediaYear" min="1900" max="2035" placeholder="2026">
          </div>
          <div class="form-group">
            <label for="mediaRuntime">Runtime (minutes)</label>
            <input type="number" id="mediaRuntime" min="1" max="600" placeholder="120">
          </div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
          <div class="form-group">
            <label for="mediaRating">IMDb Rating</label>
            <input type="number" id="mediaRating" step="0.1" min="0" max="10" placeholder="8.5">
          </div>
          <div class="form-group">
            <label for="mediaIndustry">Industry</label>
            <select id="mediaIndustry">
              <option value="Hollywood">Hollywood</option>
              <option value="Bollywood">Bollywood</option>
              <option value="Anime">Anime</option>
              <option value="Korean">Korean</option>
              <option value="Global">Global</option>
            </select>
          </div>
        </div>

        <div class="form-group">
          <label for="mediaGenres">Genres (Comma separated)</label>
          <input type="text" id="mediaGenres" placeholder="Action, Sci-Fi, Drama">
        </div>

        <div class="form-group">
          <label for="mediaPoster">Poster Image URL</label>
          <input type="url" id="mediaPoster" placeholder="https://..." required>
        </div>

        <div class="form-group">
          <label for="mediaOverview">Synopsis / Overview</label>
          <textarea id="mediaOverview" rows="3" placeholder="Plot synopsis..."></textarea>
        </div>

        <p class="admin-err" id="mediaErr"></p>
        <button class="submit-btn" id="saveMediaBtn" type="submit">Add to Curated Recommendations</button>
      </form>
    </div>

    <!-- Step 3 (Alternative): Directory Form (Website, Movie App, Music App) -->
    <div class="admin-step" id="stepDirectory">
      <form id="dirForm">
        <div class="form-group">
          <label for="dirName">Name</label>
          <input type="text" id="dirName" placeholder="e.g. CineHub or SoundVibe" required>
        </div>

        <div class="form-group">
          <label for="dirUrl">Website URL</label>
          <input type="url" id="dirUrl" placeholder="https://..." required>
        </div>

        <div class="form-group" id="dlGroup">
          <label for="dirDlUrl">Direct APK Download URL (For Apps)</label>
          <input type="url" id="dirDlUrl" placeholder="https://...app.apk">
        </div>

        <div class="form-group">
          <label for="dirAds">Ad Level</label>
          <select id="dirAds">
            <option value="0">No / minimal ads</option>
            <option value="1">Some ads</option>
            <option value="2">More / heavier ads</option>
          </select>
        </div>

        <div class="form-group">
          <label for="dirDesc">Description</label>
          <textarea id="dirDesc" rows="2" placeholder="Brief description of this streaming service..."></textarea>
        </div>

        <p class="admin-err" id="dirErr"></p>
        <button class="submit-btn" id="saveDirBtn" type="submit">Add to Directory</button>
      </form>
    </div>

  </div>
</div>
`;

resultHtml = resultHtml.replace("</body>", adminMarkup + "\n</body>");

// 3. Update the logic script for:
// - Direct card download button in appCard
// - iOS fade transitions on mode switch
// - Add listing controller logic
const updatedScript = `
<script>
// StreamCloud Add Listing Controller & iOS Enhancement
(function() {
  const PIN_SECRET = "6993";
  let activePin = "";
  let selectedCategory = "movie";

  const modal = document.getElementById("adminModal");
  const scrim = document.getElementById("adminScrim");
  const closeBtn = document.getElementById("adminCloseBtn");
  const openBtn = document.getElementById("portalAddBtn");
  const toastEl = document.getElementById("adminToast");

  // Steps
  const stepPin = document.getElementById("stepPin");
  const stepCategory = document.getElementById("stepCategory");
  const stepMedia = document.getElementById("stepMedia");
  const stepDirectory = document.getElementById("stepDirectory");

  // Inputs
  const pinInput = document.getElementById("adminPinInput");
  const pinErr = document.getElementById("pinErr");
  const verifyPinBtn = document.getElementById("verifyPinBtn");

  const catBtns = document.querySelectorAll(".cat-btn");
  const chooseCatBtn = document.getElementById("chooseCatBtn");
  const catErr = document.getElementById("catErr");

  // Media Inputs
  const mediaForm = document.getElementById("mediaForm");
  const mediaSearchTitle = document.getElementById("mediaSearchTitle");
  const enrichBtn = document.getElementById("enrichBtn");
  const imdbPreviewCard = document.getElementById("imdbPreviewCard");
  const previewPoster = document.getElementById("previewPoster");
  const previewRating = document.getElementById("previewRating");
  const previewTitle = document.getElementById("previewTitle");
  const previewSub = document.getElementById("previewSub");
  const previewPlot = document.getElementById("previewPlot");
  const mediaYear = document.getElementById("mediaYear");
  const mediaRuntime = document.getElementById("mediaRuntime");
  const mediaRating = document.getElementById("mediaRating");
  const mediaIndustry = document.getElementById("mediaIndustry");
  const mediaGenres = document.getElementById("mediaGenres");
  const mediaPoster = document.getElementById("mediaPoster");
  const mediaOverview = document.getElementById("mediaOverview");
  const mediaErr = document.getElementById("mediaErr");
  const saveMediaBtn = document.getElementById("saveMediaBtn");

  // Directory Inputs
  const dirForm = document.getElementById("dirForm");
  const dirName = document.getElementById("dirName");
  const dirUrl = document.getElementById("dirUrl");
  const dirDlUrl = document.getElementById("dirDlUrl");
  const dlGroup = document.getElementById("dlGroup");
  const dirAds = document.getElementById("dirAds");
  const dirDesc = document.getElementById("dirDesc");
  const dirErr = document.getElementById("dirErr");

  function showToast(msg) {
    if (!toastEl) return;
    toastEl.textContent = msg;
    toastEl.classList.add("show");
    setTimeout(() => toastEl.classList.remove("show"), 3200);
  }

  function openModal() {
    modal.classList.add("open");
    modal.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
    showStep(activePin === PIN_SECRET ? "stepCategory" : "stepPin");
    if (activePin !== PIN_SECRET) {
      pinInput.value = "";
      pinErr.textContent = "";
      setTimeout(() => pinInput.focus(), 60);
    }
  }

  function closeModal() {
    modal.classList.remove("open");
    modal.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
  }

  function showStep(id) {
    [stepPin, stepCategory, stepMedia, stepDirectory].forEach(el => el.classList.remove("active"));
    const target = document.getElementById(id);
    if (target) target.classList.add("active");
  }

  if (openBtn) openBtn.addEventListener("click", openModal);
  if (closeBtn) closeBtn.addEventListener("click", closeModal);
  if (scrim) scrim.addEventListener("click", closeModal);

  // PIN Verification
  function verifyPin() {
    const entered = pinInput.value.trim();
    if (entered === PIN_SECRET) {
      activePin = entered;
      pinErr.textContent = "";
      showStep("stepCategory");
    } else {
      pinErr.textContent = "Invalid access code. Please try again.";
      pinInput.value = "";
      pinInput.focus();
    }
  }
  if (verifyPinBtn) verifyPinBtn.addEventListener("click", verifyPin);
  if (pinInput) {
    pinInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") verifyPin();
    });
  }

  // Category Selection
  catBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      catBtns.forEach(b => b.classList.remove("selected"));
      btn.classList.add("selected");
      selectedCategory = btn.dataset.cat;
    });
  });

  if (chooseCatBtn) {
    chooseCatBtn.addEventListener("click", () => {
      if (!selectedCategory) {
        catErr.textContent = "Please select a category.";
        return;
      }
      catErr.textContent = "";
      if (selectedCategory === "movie" || selectedCategory === "series") {
        document.getElementById("adminTitle").textContent = "Add " + (selectedCategory === "movie" ? "Movie" : "Web Series");
        showStep("stepMedia");
        setTimeout(() => mediaSearchTitle.focus(), 50);
      } else {
        document.getElementById("adminTitle").textContent = "Add " + (selectedCategory === "sites" ? "Website" : (selectedCategory === "apps" ? "Movie App" : "Music App"));
        dlGroup.style.display = (selectedCategory === "sites") ? "none" : "block";
        showStep("stepDirectory");
        setTimeout(() => dirName.focus(), 50);
      }
    });
  }

  // Auto-enrichment
  async function triggerEnrichment() {
    const title = mediaSearchTitle.value.trim();
    if (!title) return;
    enrichBtn.disabled = true;
    enrichBtn.textContent = "Fetching...";
    mediaErr.textContent = "";

    try {
      const res = await fetch("/api/enrich-movie", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, type: selectedCategory })
      });
      const data = await res.json();
      if (data.success && data.data) {
        const d = data.data;
        mediaSearchTitle.value = d.title || title;
        mediaYear.value = d.year || "";
        mediaRuntime.value = d.runtime || "";
        mediaRating.value = d.rating?.value || "";
        if (d.genres) mediaGenres.value = Array.isArray(d.genres) ? d.genres.join(", ") : d.genres;
        if (d.poster) mediaPoster.value = d.poster;
        if (d.overview) mediaOverview.value = d.overview;
        if (d.industry) mediaIndustry.value = d.industry;

        // Populate and display preview card
        previewPoster.src = d.poster || "";
        previewRating.textContent = "⭐ " + (d.rating?.value ? d.rating.value + " / 10" : "IMDb Verified");
        previewTitle.textContent = d.title || title;
        previewSub.textContent = (d.year || "") + " · " + (Array.isArray(d.genres) ? d.genres.join(", ") : "");
        previewPlot.textContent = d.overview || "No synopsis available.";
        imdbPreviewCard.style.display = "flex";
      } else {
        mediaErr.textContent = "Auto-enrichment could not find details. You can fill the fields manually.";
      }
    } catch (e) {
      console.warn("Enrichment error:", e);
      mediaErr.textContent = "Auto-enrichment service error. Fill in fields manually.";
    } finally {
      enrichBtn.disabled = false;
      enrichBtn.textContent = "⭐ Fetch IMDb";
    }
  }

  if (enrichBtn) enrichBtn.addEventListener("click", triggerEnrichment);
  if (mediaSearchTitle) {
    mediaSearchTitle.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        triggerEnrichment();
      }
    });
  }

  // Submit Media Form (Movie / Series)
  if (mediaForm) {
    mediaForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      saveMediaBtn.disabled = true;
      saveMediaBtn.textContent = "Adding...";
      mediaErr.textContent = "";

      const payload = {
        title: mediaSearchTitle.value.trim(),
        year: parseInt(mediaYear.value, 10) || new Date().getFullYear(),
        runtime: parseInt(mediaRuntime.value, 10) || 120,
        rating: { source: "IMDb", value: parseFloat(mediaRating.value) || 8.0 },
        industry: mediaIndustry.value,
        genres: mediaGenres.value.split(",").map(g => g.trim()).filter(Boolean),
        poster: mediaPoster.value.trim(),
        overview: mediaOverview.value.trim()
      };

      try {
        const res = await fetch("/api/listings", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            pin: activePin,
            category: selectedCategory,
            data: payload
          })
        });
        const out = await res.json();
        if (out.success) {
          showToast("Added \\"" + payload.title + "\\" to " + (selectedCategory === "movie" ? "Movies" : "Web Series") + "!");
          closeModal();
          mediaForm.reset();
          imdbPreviewCard.style.display = "none";
          // Instant reload recommendations
          if (window.__reloadRecommendations) {
            window.__reloadRecommendations();
          }
          const recsSec = document.getElementById("recs");
          if (recsSec) recsSec.scrollIntoView({ behavior: "smooth" });
        } else {
          mediaErr.textContent = out.error || "Failed to add listing.";
        }
      } catch (err) {
        mediaErr.textContent = "Network error: " + err.message;
      } finally {
        saveMediaBtn.disabled = false;
        saveMediaBtn.textContent = "Add to Curated Recommendations";
      }
    });
  }

  // Submit Directory Form (Website / Movie App / Music App)
  if (dirForm) {
    dirForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const saveDirBtn = document.getElementById("saveDirBtn");
      saveDirBtn.disabled = true;
      saveDirBtn.textContent = "Adding...";
      dirErr.textContent = "";

      const payload = {
        name: dirName.value.trim(),
        url: dirUrl.value.trim(),
        downloadUrl: dirDlUrl.value.trim() || undefined,
        ads: parseInt(dirAds.value, 10) || 0,
        desc: dirDesc.value.trim() || undefined
      };

      try {
        const res = await fetch("/api/listings", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            pin: activePin,
            category: selectedCategory,
            data: payload
          })
        });
        const out = await res.json();
        if (out.success && out.item) {
          showToast("Added \\"" + payload.name + "\\" to directory!");
          closeModal();
          dirForm.reset();

          // Push into live arrays S, A, or M
          if (selectedCategory === "sites" && typeof S !== "undefined") {
            S.unshift(out.item);
            if (typeof renderView === "function") renderView("sites");
          } else if (selectedCategory === "apps" && typeof A !== "undefined") {
            A.unshift(out.item);
            if (typeof renderView === "function") renderView("apps");
          } else if (selectedCategory === "music" && typeof M !== "undefined") {
            M.unshift(out.item);
            if (typeof renderView === "function") renderView("music");
          }
        } else {
          dirErr.textContent = out.error || "Failed to add listing.";
        }
      } catch (err) {
        dirErr.textContent = "Network error: " + err.message;
      } finally {
        saveDirBtn.disabled = false;
        saveDirBtn.textContent = "Add to Directory";
      }
    });
  }

  // Load custom listings on startup
  fetch("/api/listings")
    .then(r => r.json())
    .then(items => {
      if (Array.isArray(items) && items.length > 0) {
        items.forEach(it => {
          if (it.kind === "site" && typeof S !== "undefined") {
            if (!S.some(x => x.name.toLowerCase() === it.name.toLowerCase())) S.unshift(it);
          } else if (it.appType === "music" && typeof M !== "undefined") {
            if (!M.some(x => x.name.toLowerCase() === it.name.toLowerCase())) M.unshift(it);
          } else if (typeof A !== "undefined") {
            if (!A.some(x => x.name.toLowerCase() === it.name.toLowerCase())) A.unshift(it);
          }
        });
        if (typeof renderView === "function") {
          renderView("sites");
          renderView("apps");
        }
      }
    })
    .catch(() => {});
})();
</script>
`;

resultHtml = resultHtml.replace("</body>", updatedScript + "\n</body>");

// 4. Update appCard and mode switcher in resultHtml
// Replace appCard downloadButton with direct single download button
const oldAppCardTarget = `  const downloadButton=hasDownloadUrl
    ?"<a class='open-link download-link' "+(directUrl?"data-direct-download='true'":"data-download-page='true'")+" href='"+clean(it.downloadUrl)+"' rel='nofollow' aria-label='Download "+clean(it.name)+"'>Download <span aria-hidden='true'>↧</span></a>"
    :"<button class='open-link download-link download-unavailable' type='button' disabled aria-disabled='true' title='A verified download link is not available yet'>Download</button>";`;

const newAppCardReplacement = `  const slug=String(it.name||"").toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"");
  const directDlRoute = "/api/download?app=" + encodeURIComponent(slug);
  const dlUrl = it.downloadUrl || directDlRoute;
  const downloadButton = "<a class='open-link download-link direct-card-dl' href='"+clean(dlUrl)+"' download aria-label='Direct Download "+clean(it.name)+"' style='background:linear-gradient(135deg, #e50914, #b20710);color:#fff;font-weight:700;display:inline-flex;align-items:center;gap:6px;padding:9px 18px;border-radius:8px;text-decoration:none;'>Direct Download <span aria-hidden='true'>↧</span></a>";`;

resultHtml = resultHtml.replace(oldAppCardTarget, newAppCardReplacement);

// Update renderView and mode click logic
const oldRenderViewTarget = `function renderView(type){
  const el=document.getElementById(type==="sites"?"sitesView":"appsView");
  const data=type==="sites"?S:A;
  const sorted=data.slice().sort((a,b)=>qualityScore(b)-qualityScore(a));
  if(type==="sites"){
    el.innerHTML=rowHTML("Movie Websites",sorted,{kind:"site",note:"Your curated StreamCloud collection"});
  }else{
    el.innerHTML=rowHTML("Movie Apps",sorted,{kind:"app",note:"Direct APK links and app information"});
  }
}

renderView("sites");
renderView("apps");
document.querySelectorAll('.track').forEach(function(t){t.querySelectorAll('.card').forEach(function(card,i){card.style.animationDelay=(Math.min(i,8)*55)+'ms'})});
function svgPlay(){return "<svg viewBox='0 0 24 24' fill='currentColor'><path d='M6 4l14 8-14 8z'/></svg>"}
function svgPlus(){return "<svg viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='3' stroke-linecap='round'><path d='M12 5v14M5 12h14'/></svg>"}
function rowHTML(title,items,opts){
  if(!items.length)return "";
  var top=opts&&opts.top;
  var note=opts&&opts.note?opts.note:"";
  return "<section class='row "+(top?"top10 ":"")+"row-section' data-row='"+clean(title.toLowerCase())+"'><div class='row-head'><h2>"+clean(title)+"</h2><span class='row-note'>"+clean(note)+"</span></div><div class='rail'><button class='arrow l' aria-label='Scroll left'>&#8249;</button><div class='track'>"+items.map(function(it,i){return card(it,i,top)}).join("")+"</div><button class='arrow r' aria-label='Scroll right'>&#8250;</button></div></section>";
}

function setHero(type){}

document.querySelectorAll(".mode").forEach(function(btn){
  btn.addEventListener("click",function(){
    document.querySelectorAll(".mode").forEach(function(x){x.classList.remove("active");x.setAttribute("aria-selected","false")});
    btn.classList.add("active");btn.setAttribute("aria-selected","true");
    var mode=btn.dataset.mode;
    document.getElementById("sitesView").classList.toggle("active",mode==="sites");
    document.getElementById("appsView").classList.toggle("active",mode!=="sites");
    document.getElementById("q").value="";
    document.getElementById("empty").style.display="none";
      });
});`;

const newRenderViewReplacement = `function renderView(type){
  const el=document.getElementById(type==="sites"?"sitesView":"appsView");
  const data=type==="sites"?S:(type==="music"?M:A);
  const sorted=data.slice().sort((a,b)=>qualityScore(b)-qualityScore(a));
  if(type==="sites"){
    el.innerHTML=rowHTML("Movie Websites",sorted,{kind:"site",note:"Your curated StreamCloud collection"});
  }else if(type==="music"){
    el.innerHTML=rowHTML("Music Apps",sorted,{kind:"app",note:"Direct streaming APKs and audio players"});
  }else{
    el.innerHTML=rowHTML("Movie Apps",sorted,{kind:"app",note:"Direct APK links and app information"});
  }
}

renderView("sites");
renderView("apps");
document.querySelectorAll('.track').forEach(function(t){t.querySelectorAll('.card').forEach(function(card,i){card.style.animationDelay=(Math.min(i,8)*55)+'ms'})});
function svgPlay(){return "<svg viewBox='0 0 24 24' fill='currentColor'><path d='M6 4l14 8-14 8z'/></svg>"}
function svgPlus(){return "<svg viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='3' stroke-linecap='round'><path d='M12 5v14M5 12h14'/></svg>"}
function rowHTML(title,items,opts){
  if(!items.length)return "";
  var top=opts&&opts.top;
  var note=opts&&opts.note?opts.note:"";
  return "<section class='row "+(top?"top10 ":"")+"row-section' data-row='"+clean(title.toLowerCase())+"'><div class='row-head'><h2>"+clean(title)+"</h2><span class='row-note'>"+clean(note)+"</span></div><div class='rail'><button class='arrow l' aria-label='Scroll left'>&#8249;</button><div class='track'>"+items.map(function(it,i){return card(it,i,top)}).join("")+"</div><button class='arrow r' aria-label='Scroll right'>&#8250;</button></div></section>";
}

function setHero(type){}

document.querySelectorAll(".mode").forEach(function(btn){
  btn.addEventListener("click",function(){
    document.querySelectorAll(".mode").forEach(function(x){x.classList.remove("active");x.setAttribute("aria-selected","false")});
    btn.classList.add("active");btn.setAttribute("aria-selected","true");
    var mode=btn.dataset.mode;
    var sitesV=document.getElementById("sitesView");
    var appsV=document.getElementById("appsView");

    // iOS spring fade transition
    sitesV.classList.remove("ios-fade-in");
    appsV.classList.remove("ios-fade-in");

    if (mode === "sites") {
      sitesV.classList.add("active");
      appsV.classList.remove("active");
      renderView("sites");
      void sitesV.offsetWidth;
      sitesV.classList.add("ios-fade-in");
    } else if (mode === "apps") {
      sitesV.classList.remove("active");
      appsV.classList.add("active");
      renderView("apps");
      void appsV.offsetWidth;
      appsV.classList.add("ios-fade-in");
    } else if (mode === "music") {
      sitesV.classList.remove("active");
      appsV.classList.add("active");
      renderView("music");
      void appsV.offsetWidth;
      appsV.classList.add("ios-fade-in");
    }
    document.getElementById("q").value="";
    document.getElementById("empty").style.display="none";
  });
});`;

resultHtml = resultHtml.replace(oldRenderViewTarget, newRenderViewReplacement);

fs.writeFileSync("index.html", resultHtml, "utf-8");
console.log("Successfully generated clean index.html!");
