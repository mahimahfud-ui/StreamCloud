import express from "express";
import cookieParser from "cookie-parser";
import jwt from "jsonwebtoken";
import crypto from "crypto";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { GoogleGenAI, Type } from "@google/genai";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json({ limit: "2mb" }));
app.use(cookieParser());

// Load .env if present
const envFilePath = path.join(__dirname, ".env");
if (fs.existsSync(envFilePath)) {
  try {
    const envLines = fs.readFileSync(envFilePath, "utf-8").split("\n");
    for (const line of envLines) {
      const trimmed = line.trim();
      if (trimmed && !trimmed.startsWith("#") && trimmed.includes("=")) {
        const idx = trimmed.indexOf("=");
        const k = trimmed.slice(0, idx).trim();
        const v = trimmed.slice(idx + 1).trim().replace(/^['"]|['"]$/g, "");
        if (k && v && (!process.env[k] || process.env[k] === "MY_GEMINI_API_KEY")) {
          process.env[k] = v;
        }
      }
    }
  } catch (e) {}
}

// Admin configuration
const PIN = process.env.ADMIN_PIN || "6993";
const SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString("hex");
const DB = path.join(__dirname, "data.json");
const TYPES = ["movie", "series", "website", "movieapp", "musicapp"];

// Ensure data.json exists
if (!fs.existsSync(DB)) {
  fs.writeFileSync(DB, JSON.stringify([], null, 2));
}

// Storage helpers
const load = () => {
  try {
    return JSON.parse(fs.readFileSync(DB, "utf8"));
  } catch {
    return [];
  }
};
const save = (items) => fs.writeFileSync(DB, JSON.stringify(items, null, 2));

// Auth rate-limiter & timing-safe compare
const fails = new Map(); // ip -> {n, until}
const same = (a, b) => {
  const x = crypto.createHash("sha256").update(String(a || "")).digest();
  const y = crypto.createHash("sha256").update(String(b || "")).digest();
  return crypto.timingSafeEqual(x, y);
};

// Initialize Gemini Client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      "User-Agent": "aistudio-build"
    }
  }
});

// Admin Login
app.post("/api/admin/login", (req, res) => {
  const ip = req.ip || req.headers["x-forwarded-for"] || req.socket.remoteAddress || "127.0.0.1";
  const f = fails.get(ip) || { n: 0, until: 0 };
  if (Date.now() < f.until) {
    return res.status(429).json({ error: "Too many attempts. Try again in a few minutes." });
  }

  if (!same(String(req.body.pin || ""), PIN)) {
    f.n++;
    if (f.n >= 5) {
      f.until = Date.now() + 10 * 60 * 1000;
      f.n = 0;
    }
    fails.set(ip, f);
    return res.status(401).json({ error: "Wrong PIN." });
  }

  fails.delete(ip);
  const token = jwt.sign({ role: "admin" }, SECRET, { expiresIn: "8h" });
  res.cookie("sc_admin", token, {
    httpOnly: true,
    sameSite: "lax",
    secure: false,
    maxAge: 8 * 3600e3
  });
  res.json({ ok: true, token });
});

// Auth Guard Middleware
const guard = (req, res, next) => {
  try {
    const token = req.cookies.sc_admin || (req.headers.authorization && req.headers.authorization.replace("Bearer ", "").trim());
    if (!token) throw new Error("No token");
    jwt.verify(token, SECRET);
    if (req.method !== "GET" && req.get("X-Requested-With") !== "sc") {
      return res.status(403).json({ error: "Blocked." });
    }
    next();
  } catch {
    res.status(401).json({ error: "Not logged in." });
  }
};

app.post("/api/admin/logout", (req, res) => {
  res.clearCookie("sc_admin");
  res.json({ ok: true });
});

app.get("/api/admin/me", guard, (req, res) => res.json({ ok: true }));

// Sanitization & Validation
const s = (v, n) => String(v ?? "").trim().slice(0, n);
const url = (v) => {
  try {
    const u = new URL(v);
    return u.protocol === "https:" || u.protocol === "http:" ? u.href : "";
  } catch {
    return "";
  }
};
const clean = (b) => {
  if (!TYPES.includes(b.type)) throw new Error("Invalid type.");
  if (!s(b.name, 120)) throw new Error("Name is required.");
  return {
    type: b.type,
    name: s(b.name, 120),
    url: url(b.url),
    apk: url(b.apk),
    poster: url(b.poster),
    year: +b.year || null,
    runtime: +b.runtime || null,
    rating: Math.min(10, Math.max(0, +b.rating || 0)),
    industry: s(b.industry, 30),
    genres: s(b.genres, 200).split(",").map((g) => g.trim()).filter(Boolean),
    adLevel: ["none", "some", "more"].includes(b.adLevel) ? b.adLevel : "some",
    desc: s(b.desc, 1500),
    status: b.status === "hidden" ? "hidden" : "published",
    isNew: Boolean(b.isNew)
  };
};

// Public API
app.get("/api/items", (req, res) => {
  res.json(load().filter((i) => i.status !== "hidden"));
});

// Admin APIs
app.get("/api/admin/items", guard, (req, res) => res.json(load()));

app.post("/api/admin/items", guard, (req, res) => {
  try {
    const items = load();
    const item = {
      id: crypto.randomUUID(),
      ...clean(req.body),
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    items.unshift(item);
    save(items);
    res.json(item);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.put("/api/admin/items/:id", guard, (req, res) => {
  try {
    const items = load();
    const i = items.findIndex((x) => x.id === req.params.id);
    if (i < 0) return res.status(404).json({ error: "Not found." });
    items[i] = { ...items[i], ...clean(req.body), updatedAt: Date.now() };
    save(items);
    res.json(items[i]);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.delete("/api/admin/items/:id", guard, (req, res) => {
  save(load().filter((x) => x.id !== req.params.id));
  res.json({ ok: true });
});

app.post("/api/admin/items/bulk", guard, (req, res) => {
  const { ids = [], action } = req.body;
  let items = load();
  if (action === "delete") {
    items = items.filter((x) => !ids.includes(x.id));
  } else if (action === "hide" || action === "publish") {
    items.forEach((x) => {
      if (ids.includes(x.id)) x.status = action === "hide" ? "hidden" : "published";
    });
  } else {
    return res.status(400).json({ error: "Bad action." });
  }
  save(items);
  res.json({ ok: true });
});

app.get("/api/admin/export", guard, (req, res) => {
  res.setHeader("Content-Disposition", "attachment; filename=streamcloud-backup.json");
  res.json(load());
});

app.post("/api/admin/import", guard, (req, res) => {
  try {
    if (!Array.isArray(req.body)) throw new Error("Expected an array.");
    const now = Date.now();
    save(req.body.map((b) => ({ id: crypto.randomUUID(), ...clean(b), createdAt: now, updatedAt: now })));
    res.json({ ok: true });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

// Helper: Scrape basic metadata from URL
async function scrapeUrlMetadata(targetUrl) {
  try {
    if (!/^https?:\/\//i.test(targetUrl)) return null;
    const res = await fetch(targetUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
      },
      redirect: "follow",
      signal: AbortSignal.timeout(4500)
    });
    if (!res.ok) return null;
    const html = await res.text();
    const finalUrl = res.url || targetUrl;

    const titleMatch = html.match(/<title[^>]*>([^<]+)<\/title>/i);
    const ogTitleMatch = html.match(/<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']/i) ||
                         html.match(/<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:title["']/i);
    const ogDescMatch = html.match(/<meta[^>]+property=["']og:description["'][^>]+content=["']([^"']+)["']/i) ||
                        html.match(/<meta[^>]+name=["']description["'][^>]+content=["']([^"']+)["']/i);
    const ogImageMatch = html.match(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i) ||
                         html.match(/<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:image["']/i);

    return {
      title: (ogTitleMatch ? ogTitleMatch[1] : (titleMatch ? titleMatch[1] : "")).trim(),
      description: (ogDescMatch ? ogDescMatch[1] : "").trim(),
      ogImage: (ogImageMatch ? ogImageMatch[1] : "").trim(),
      finalUrl
    };
  } catch (e) {
    return null;
  }
}

// Universal Gemini 3.8 Flash AI URL Analyzer
app.post("/api/ai-analyze-url", async (req, res) => {
  const rawInput = String(req.body?.url || "").trim();
  if (!rawInput) {
    return res.status(400).json({ success: false, error: "URL or title is required for AI analysis." });
  }

  try {
    let scraped = null;
    if (/^https?:\/\//i.test(rawInput)) {
      scraped = await scrapeUrlMetadata(rawInput);
    }

    const prompt = `Analyze this input link / query for StreamCloud media directory:
Input URL/Text: "${rawInput}"
${scraped ? `Scraped Page Title: "${scraped.title}"\nScraped Description: "${scraped.description}"\nScraped Image: "${scraped.ogImage}"\nResolved URL: "${scraped.finalUrl}"` : ""}

Classify it into EXACTLY ONE of the 5 StreamCloud categories:
- "movie": A single feature film or movie (e.g. Inception, Avatar, IMDb movie link, Netflix/streaming movie title).
- "series": A TV show, web series, drama, or anime series (e.g. Stranger Things, Game of Thrones, anime series, TV show page).
- "sites": A streaming website or web directory for movies/series (e.g. freekz.to, soap2day, cinehd.vc, watchott, 1tube, hydrahd).
- "apps": An Android APK or streaming app for watching movies, TV shows, or anime (e.g. OnStream, Cloudstream, FilmPlus, BeeTV, HDO Box, Vega, Cinema HQ, Flix Vision).
- "music": A music streaming app, audio player, or music service (e.g. Spotify, Spotube, InnerTune, ViMusic, Echo Music, Demus, BlackHole, SimpMusic).

Extract all required metadata:
- category: Exactly one of "movie", "series", "sites", "apps", "music"
- titleOrName: Clean official title or app/site name
- canonicalUrl: Homepage, primary site, or clean web link
- downloadUrl: Direct APK download URL if app or APK, or empty string
- year: Integer release year (e.g. 2024)
- runtime: Integer runtime in minutes (for movies/series, e.g. 118) or 0
- rating: Number out of 10 (e.g. 8.4)
- industry: "Hollywood", "Bollywood", "Anime", "Korean", or "Global"
- genres: List of 2-4 relevant genres or category tags
- posterOrLogo: Direct HTTPS image URL (use scraped og:image if valid, or a relevant artwork link, or empty string)
- overviewOrDesc: Detailed 2-3 sentence overview or synopsis
- ads: Integer 0 (no/minimal ads), 1 (some ads), 2 (heavy ads)
- reasoning: 1 concise sentence explaining why this category was detected`;

    const geminiConfig = {
      systemInstruction: "You are StreamCloud's senior media curator and AI catalog classifier. Provide precise, high-accuracy metadata and classifications formatted as strict JSON.",
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          category: { type: Type.STRING, description: "Must be exactly one of: movie, series, sites, apps, music" },
          titleOrName: { type: Type.STRING, description: "Clean display title or name" },
          canonicalUrl: { type: Type.STRING, description: "Primary URL or home link" },
          downloadUrl: { type: Type.STRING, description: "Direct APK download URL if app or APK, or empty string" },
          year: { type: Type.INTEGER, description: "Release year (e.g. 2024)" },
          runtime: { type: Type.INTEGER, description: "Runtime in minutes (for movies/series)" },
          rating: { type: Type.NUMBER, description: "Rating out of 10 (e.g. 8.4)" },
          industry: { type: Type.STRING, description: "Hollywood, Bollywood, Anime, Korean, or Global" },
          genres: { type: Type.ARRAY, items: { type: Type.STRING }, description: "List of genres or tags" },
          posterOrLogo: { type: Type.STRING, description: "High quality HTTPS image URL for poster or logo, or empty string" },
          overviewOrDesc: { type: Type.STRING, description: "Comprehensive 2-3 sentence overview or description" },
          ads: { type: Type.INTEGER, description: "Ad level: 0 (minimal/no ads), 1 (some ads), 2 (heavy ads)" },
          reasoning: { type: Type.STRING, description: "Brief reason explaining why this category was detected" }
        },
        required: ["category", "titleOrName", "canonicalUrl", "overviewOrDesc", "ads", "reasoning"]
      }
    };

    let geminiRes;
    try {
      geminiRes = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: prompt,
        config: geminiConfig
      });
    } catch (err38) {
      geminiRes = await ai.models.generateContent({
        model: "gemini-3.1-flash-lite",
        contents: prompt,
        config: geminiConfig
      });
    }

    let aiData = JSON.parse(geminiRes.text.trim());
    return res.json({ success: true, data: aiData, sourceUrl: rawInput });
  } catch (err) {
    // Fallback
    const domain = rawInput.replace(/^(?:https?:\/\/)?(?:www\.)?/i, "").split("/")[0] || "StreamCloud Resource";
    return res.json({
      success: true,
      data: {
        category: "sites",
        titleOrName: domain.split(".")[0].toUpperCase() || "StreamCloud Resource",
        canonicalUrl: rawInput,
        downloadUrl: rawInput.endsWith(".apk") ? rawInput : "",
        year: 2024,
        rating: 8.0,
        industry: "Global",
        genres: ["Streaming"],
        posterOrLogo: "",
        overviewOrDesc: `Streaming platform resource: ${domain}`,
        ads: 1,
        reasoning: "Detected based on domain structure."
      }
    });
  }
});

// Direct APK download mappings
const APP_DOWNLOADS = {
  "onstream": { name: "OnStream-latest.apk", url: "https://dl.onstream.so/app/onstream-latest.apk" },
  "cloudstream": { name: "Cloudstream-pre-release.apk", url: "https://github.com/recloudstream/cloudstream/releases/latest/download/Cloudstream-Pre-Release.apk" },
  "filmplus": { name: "FilmPlus-latest.apk", url: "https://filmplus.app/dl/FilmPlus_Latest.apk" },
  "beetv": { name: "BeeTV-latest.apk", url: "https://beetv.vip/app/beetv.apk" },
  "hdo-box": { name: "HDO-Box-latest.apk", url: "https://hdo.app/apk/hdobox.apk" },
  "spotube": { name: "Spotube-android-latest.apk", url: "https://github.com/KRTirtho/spotube/releases/latest/download/Spotube-android-all-arch.apk" }
};

app.get("/api/download", async (req, res) => {
  const appSlug = String(req.query.app || "").trim().toLowerCase();
  const info = APP_DOWNLOADS[appSlug];
  if (!info) return res.status(404).send("App download not found.");

  res.setHeader("Content-Disposition", `attachment; filename="${info.name}"`);
  res.setHeader("Content-Type", "application/vnd.android.package-archive");

  try {
    const upstream = await fetch(info.url, {
      headers: { "User-Agent": "Mozilla/5.0" },
      redirect: "follow"
    });
    if (upstream.ok && upstream.body) {
      const nodeStream = upstream.body;
      if (typeof nodeStream.pipe === "function") {
        nodeStream.pipe(res);
      } else {
        const reader = nodeStream.getReader();
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          res.write(value);
        }
        res.end();
      }
    } else {
      res.redirect(302, info.url);
    }
  } catch (err) {
    res.redirect(302, info.url);
  }
});

// Real Link Status Checker
app.get("/api/check-link", async (req, res) => {
  const targetUrl = String(req.query.url || "").trim();
  if (!targetUrl || !/^https?:\/\//i.test(targetUrl)) {
    return res.status(400).json({ ok: false, error: "Valid URL required" });
  }

  const startTime = Date.now();
  try {
    const resp = await fetch(targetUrl, {
      method: "HEAD",
      headers: { "User-Agent": "StreamCloud-LinkChecker/1.0" },
      signal: AbortSignal.timeout(3500),
      redirect: "follow"
    });
    const latencyMs = Date.now() - startTime;
    return res.json({ ok: resp.status < 400 || resp.status === 403, status: resp.status, latencyMs });
  } catch (err) {
    return res.json({ ok: false, status: 0, latencyMs: Date.now() - startTime, error: "Timeout or unreachable" });
  }
});

// Recommendations and Listings compatibility
app.get("/api/recommendations", (req, res) => {
  const items = load();
  const movies = items.filter((i) => i.type === "movie");
  const series = items.filter((i) => i.type === "series");
  res.json({ movies, series });
});

app.get("/api/listings", (req, res) => {
  const items = load();
  res.json(items.filter((i) => ["website", "movieapp", "musicapp"].includes(i.type)));
});

// Admin Route
app.get("/admin", (req, res) => {
  res.sendFile(path.join(__dirname, "admin.html"));
});

// Static files
app.use(express.static(__dirname, { index: "index.html", extensions: ["html"] }));

// Single-page fallback
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "index.html"));
});

// Listen on port 3000
const PORT = process.env.PORT || 3000;
app.listen(PORT, "0.0.0.0", () => {
  console.log(`StreamCloud running on http://0.0.0.0:${PORT}`);
});
