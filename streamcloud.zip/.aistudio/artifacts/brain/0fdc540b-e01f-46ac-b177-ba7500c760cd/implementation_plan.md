# StreamCloud Authentic UI Restoration & Dedicated Admin Panel Upgrade

Restore the authentic, pixel-perfect StreamCloud frontend interface from the official repository (WebGL cinema canvas, Netflix-style intro sequence, channel jump portal, glowing cards, and recommendations) and upgrade the administration system to the user-specified standalone Admin Console at `/admin` with JWT cookie authentication, 4-digit PIN box, bulk operations, JSON import/export, and Gemini 3.8 Flash AI auto-fill.

## User Review & Critical Decisions

> [!IMPORTANT]
> The following decisions were confirmed by the user in Phase 1:
> - **Main Site Experience**: Restore the exact original StreamCloud UI from the repository (`https://github.com/mahimahfud-ui/StreamCloud`) with complete WebGL cinema canvas, light sweep intro, channel jump portal, and animations.
> - **Admin Integration**: Implement a dedicated `admin.html` served at route `/admin` powered by server-side JWT cookie authentication (`sc_admin`), timing-safe PIN check, rate-limiting, and `data.json` persistence.
> - **AI Integration**: Retain and embed the Gemini 3.8 Flash AI URL Auto-Detect feature directly inside the upgraded admin modal to automatically classify links and pre-populate metadata.

---

## 1. Overview & Core Concept

- **What It Does**:
  - **Public Experience (`/`)**: Delivers the authentic, dark cinematic StreamCloud web application—featuring real-time WebGL space dust, light sweep intro animation, glowing curated cards for Websites, Movie Apps, and Music Apps, an interactive channel jump portal, and recommendation rails for Movies & Web Series.
  - **Admin Console (`/admin`)**: A dedicated administration interface accessed via a 4-digit PIN box with auto-focus, paste support, and shake feedback. Once unlocked via JWT cookie (`sc_admin`), administrators can manage, search, filter, bulk-publish/hide/delete, export, import, and AI-auto-fill media catalog entries stored in `data.json`.
- **Target Audience**: Media enthusiasts streaming movies, series, and music seeking an ad-aware, curated catalog, plus administrators who need a zero-friction, secure management panel.
- **Key Value**: Preserves the complete visual identity and WebGL effects of StreamCloud while providing an enterprise-grade admin workspace that eliminates manual data entry using Gemini AI.

---

## 2. User Experience & Visual Design

### Public Interface (`/`)
- **Atmosphere & WebGL**: Deep obsidian palette (`#0d0d0e`, `#141414`) with dynamic WebGL particles (`cinema/scene.js`), glowing crimson radial accents, and light-sweep intro.
- **Hero & Channel Jump Portal**: Bebas Neue display typography, Instagram community badge, and the 3D channel jump portal allowing instant transit between catalog categories.
- **Modes & Rows**: Segmented controls for Websites, Movie Apps, and Music Apps, plus Top 10 rankings, freshness tags (`NEW`), ad-level indicators (`NO AD`, `LESS AD`, `MORE AD`), and direct APK download badges.
- **Recommendations Rail**: Curated Movies and Web Series tabs with IMDb ratings, genres, and detail inspection modals.

### Admin Console (`/admin`)
- **Login View**: Centered glassmorphic card on an aurora backdrop with a 4-digit PIN input group, automatic focus advancing, paste handling, timing-safe server validation, and CSS shake feedback on failure.
- **App Shell & Sidebar**: Desktop sidebar ($230\text{px}$) and mobile bottom navigation with quick filters: All Listings, Movies, Web Series, Websites, Movie Apps, Music Apps, View Site, and Log Out.
- **Dashboard Summary & Toolbar**: Live metric tiles (Total, Published, Hidden, Apps), search input, publication status dropdown, and contextual bulk action triggers (Publish, Hide, Delete selected).
- **Data Grid**: Dense table with item checkboxes, lazy-loaded poster thumbnails, category tags, ratings, ad levels, and status indicators (`Published` in green, `Hidden` in amber).
- **Listing Form Modal**: 2-column modal supporting manual edits or 1-click Gemini AI auto-detection (paste any link $\rightarrow$ Gemini extracts category, name, poster, year, rating, industry, genres, and synopsis).

---

## 3. Key Product Decisions & Trade-Offs

- **Exact Repository Code vs. New Theme**:
  - *Chosen Approach*: Restore the authentic `gh-index.html` structure as `index.html` so all animations, WebGL canvas modules, and CSS rules from `https://github.com/mahimahfud-ui/StreamCloud` execute natively without missing dependencies.
  - *Why*: Directly aligns with user requirement for "hubhu copy (identical) with theme animation sob milay".
- **Dedicated Route (`/admin`) vs. Embedded Overlay**:
  - *Chosen Approach*: Serve `admin.html` as a standalone page protected by HTTP-only JWT cookies (`sc_admin`) with fallback to public home (`/`).
  - *Why*: Guarantees zero administrative code or PIN leakage in the public bundle and satisfies strict separation of concerns.
- **Unified Catalog Storage (`data.json`)**:
  - *Chosen Approach*: Power the `/api/items` and `/api/admin/items` endpoints with `data.json`, pre-seeded from existing repository catalog data (`recommendations.json` + `custom-listings.json`).
  - *Why*: Provides clean, transactional persistence that supports bulk mutations, instant imports, and complete backups without breaking existing catalog items.

---

## 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                        StreamCloud Architecture                        │
└────────────────────────────────────────────────────────────────────────┘

 [ Client Browser: Public View (/) ]     [ Client Browser: Admin View (/admin) ]
            │                                             │
            ▼                                             ▼
 ┌──────────────────────┐                     ┌──────────────────────┐
 │ index.html (Catalog) │                     │ admin.html (Console) │
 │ - WebGL Space Dust   │                     │ - 4-Box PIN Auth     │
 │ - Intro Light Sweep  │                     │ - High-Density Grid  │
 │ - Jump Portal 3D     │                     │ - Bulk Actions       │
 │ - Detail Modals      │                     │ - Gemini AI Importer │
 └──────────┬───────────┘                     └──────────┬───────────┘
            │                                            │
            │ GET /api/items                             │ JWT Cookie Auth
            │ GET /api/recommendations                   │ /api/admin/*
            ▼                                            ▼
 ┌───────────────────────────────────────────────────────────────────────┐
 │                   Express Server (server.js - Node.js)                │
 │  - cookie-parser + jsonwebtoken (8-hour secure session)              │
 │  - Rate Limiter & timingSafeEqual PIN verification                    │
 │  - Gemini 3.8 Flash Multi-Model URL Auto-Analyzer                     │
 │  - Direct APK Stream Downloader (/api/download)                       │
 └──────────────────────────────────┬────────────────────────────────────┘
                                    │
                                    ▼
 ┌───────────────────────────────────────────────────────────────────────┐
 │                            File Persistence                           │
 │  - data.json: Unified administration database                         │
 │  - data/recommendations.json: Curated movies & series                 │
 │  - data/custom-listings.json: Custom websites & APK listings          │
 └───────────────────────────────────────────────────────────────────────┘
```

### Planned Implementation Steps
1. **Dependency Installation**: Install `cookie-parser` and `jsonwebtoken` via `install_applet_package`.
2. **Catalog Seeding**: Ensure `data.json` is initialized with all current listings from `data/recommendations.json` and existing catalog arrays.
3. **Public Interface (`index.html`)**: Update `index.html` from `gh-index.html` to restore the full authentic visual design, WebGL canvas, channel jump portal, and styling.
4. **Admin Interface (`admin.html`)**: Create `admin.html` with the user-provided layout, 4-digit PIN box, data grid, bulk actions, and the Gemini AI Auto-Detect URL button.
5. **Server Backend (`server.js`)**: Implement the complete admin backend (JWT cookie auth, timing-safe PIN check, `/api/items`, `/api/admin/items`, `/api/admin/items/bulk`, `/api/admin/export`, `/api/admin/import`, and `/api/ai-analyze-url`).
6. **Validation & Verification**: Run `scripts/validate.mjs` and `compile_applet` to ensure full compliance.
